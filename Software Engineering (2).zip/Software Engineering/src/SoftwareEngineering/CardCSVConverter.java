package SoftwareEngineering;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.util.ArrayList;
import java.util.Scanner;

public class CardCSVConverter {
    public static ArrayList<String> cardData;
    public File file;
    public Scanner inputStream;
    private ArrayList<Card> potLuck;
    private ArrayList<Card> oppurtunityKnocks;

    public CardCSVConverter(String filePath) throws FileNotFoundException {
        this.file = new File(filePath);
        this.inputStream = new Scanner(new BufferedReader(new FileReader(file)));
        cardData = new ArrayList<String>();
        potLuck = new ArrayList<Card>();
        oppurtunityKnocks = new ArrayList<Card>();
    }

    public void initializeCardData(){
        while (inputStream.hasNext()) {
            String data = inputStream.nextLine();
            cardData.add(data);
        }
        inputStream.close();
    }

    public void setCardData() {
        for(int i=0; i < cardData.size(); i++){
            String[] temp = cardData.get(i).split(",,,");
            if(i >= 5 && i<= 20){
                potLuck.add(new Card(temp[0],temp[1]));
            }
            else if(i>=25){
                oppurtunityKnocks.add(new Card(temp[0],temp[1]));
            }
        }
    }

    public ArrayList<Card> getPotLuckData(){
        return this.potLuck;
    }

    public ArrayList<Card> getOppurtunityKnocksData(){
        return this.oppurtunityKnocks;
    }

    public static void main(String[] args) throws FileNotFoundException {
        CardCSVConverter convert = new CardCSVConverter("src/SoftwareEngineering/CSVData/PropertyTycoonCardData.csv");
        convert.initializeCardData();
        convert.setCardData();
        for(Card element:convert.getPotLuckData()){
            System.out.println("description: "+element.getDescription()+"  action: "+element.getAction());
        }
        System.out.println("--------------------------------I like cats------------------------------------");
        for(Card element:convert.getOppurtunityKnocksData()){
            System.out.println("description: "+element.getDescription()+"  action: "+element.getAction());
        }
    }
}


