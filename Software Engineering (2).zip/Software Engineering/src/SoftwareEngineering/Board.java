package SoftwareEngineering;

import java.io.FileNotFoundException;
import java.util.ArrayList;

public class Board {
    public ArrayList<Square> allSquares;
    public ArrayList<Player> allPlayers;
    public ArrayList<Card> potLuck;
    public ArrayList<Card> oppurtunityKnocks;
    public int currentPlayer;

    public Board(int numOfPlayers, String boardDataFilePath, String cardDataFilePath) throws FileNotFoundException {
        this.allPlayers = new ArrayList<Player>();
        for (int id = 1; id <= numOfPlayers; id++) {
            this.allPlayers.add(new Player(id));
        }
        this.currentPlayer = 0;

        BoardCSVConverter convertBoard = new BoardCSVConverter(boardDataFilePath);
        convertBoard.initializeBoardData();
        convertBoard.setBoardData();
        this.allSquares = convertBoard.getSquareData();

        CardCSVConverter convertCards = new CardCSVConverter(cardDataFilePath);
        convertCards.initializeCardData();
        convertCards.setCardData();
        this.potLuck = convertCards.getPotLuckData();
        this.oppurtunityKnocks = convertCards.getOppurtunityKnocksData();

    }

    public void setNextPlayer() {
        if (currentPlayer == allPlayers.size() - 1) {
            currentPlayer = 0;
        } else {
            currentPlayer++;
        }
    }

    public ArrayList<Square> getAllSquares() {
        return this.allSquares;
    }

    public ArrayList<Player> getAllPlayers() {
        return this.allPlayers;
    }

    public ArrayList<Card> getPotLuck(){
        return this.potLuck;
    }

    public ArrayList<Card> getOppurtunityKnocks(){
        return this.oppurtunityKnocks;
    }


    public int getCurrentPlayer() {
        return this.currentPlayer;
    }
}
