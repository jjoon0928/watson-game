package SoftwareEngineering;

import javafx.scene.image.Image;
import javafx.scene.layout.BackgroundImage;
import javafx.scene.layout.BackgroundPosition;
import javafx.scene.layout.BackgroundRepeat;
import javafx.scene.layout.BackgroundSize;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Scanner;

public class BoardCSVConverter {
    public static ArrayList<String> boardData;
    public ArrayList<Square> squareData;
    public File file;
    public Scanner inputStream;

    public BoardCSVConverter(String filePath) throws FileNotFoundException {
        this.file = new File(filePath);
        this.inputStream = new Scanner(new BufferedReader(new FileReader(file)));
        boardData = new ArrayList<String>();
        squareData = new ArrayList<Square>();
    }

    public void initializeBoardData() {
        while (inputStream.hasNext()) {
            String data = inputStream.nextLine();
            boardData.add(data);
        }
        inputStream.close();
    }

    public void setBoardData() {
        for (int i = 0; i < boardData.size(); i++) {
            if (i >= 4 && i <= 43) {
                String[] temp = boardData.get(i).split(",");
                //System.out.println(Arrays.toString(temp));
                //System.out.println(temp.length);
                boolean canBeBought = true;
                if (temp[5].toLowerCase().equals("no")) {
                    canBeBought = false;
                }
                if (temp.length == 6) {
                    squareData.add(new Square(Integer.parseInt(temp[0]), temp[1], temp[4], canBeBought));
                } else if (temp.length == 9) {
                    squareData.add(new Square(Integer.parseInt(temp[0]), temp[1], temp[3].toLowerCase(), canBeBought,
                            Integer.parseInt(temp[7].replaceAll("[^0-9.]", "")), new Property(temp[3])));
                } else if (temp.length == 15) {
                    squareData.add(new Square(Integer.parseInt(temp[0]), temp[1], temp[3].toLowerCase(), canBeBought, Integer.parseInt(temp[7]),
                            new Property(Integer.parseInt(temp[8]), Integer.parseInt(temp[10]), Integer.parseInt(temp[11]), Integer.parseInt(temp[12]),
                                    Integer.parseInt(temp[13]), Integer.parseInt(temp[14]))));
                }
            }
        }
    }

    public ArrayList<Square> getSquareData() {
        return this.squareData;
    }

    public static void main(String[] args) throws FileNotFoundException {
        BoardCSVConverter convert = new BoardCSVConverter("src/SoftwareEngineering/CSVData/PropertyTycoonBoardData.csv");
        convert.initializeBoardData();
        convert.setBoardData();
        for (Square s : convert.getSquareData()) {
            System.out.println("Position: " + s.getPosition() + ", Name: " + s.getName() + ", Group: " + s.getGroup() +
                    ", Action: " + s.getAction() + ", Buyable: " + s.getCanBeBought() + ", Cost: " + s.getCost());
            if(s.getProperty() != null){
                System.out.println("Property Type: "+ s.getProperty().getType());
            }
        }
    }
}
