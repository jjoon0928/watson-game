package SoftwareEngineering;

import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.*;

import java.net.URL;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.ResourceBundle;

public class Controller implements Initializable {
    public StackPane StackPane1, StackPane2, StackPane3, StackPane4, StackPane5, StackPane6, StackPane7, StackPane8, StackPane9, StackPane10,
            StackPane11, StackPane12, StackPane13, StackPane14, StackPane15, StackPane16, StackPane17, StackPane18, StackPane19, StackPane20,
            StackPane21, StackPane22, StackPane23, StackPane24, StackPane25, StackPane26, StackPane27, StackPane28, StackPane29, StackPane30,
            StackPane31, StackPane32, StackPane33, StackPane34, StackPane35, StackPane36, StackPane37, StackPane38, StackPane39, StackPane40;
    public ImageView Image1, Image2, Image3, Image4, Image5, Image6, Image7, Image8, Image9, Image10,
            Image11, Image12, Image13, Image14, Image15, Image16, Image17, Image18, Image19, Image20,
            Image21, Image22, Image23, Image24, Image25, Image26, Image27, Image28, Image29, Image30,
            Image31, Image32, Image33, Image34, Image35, Image36, Image37, Image38, Image39, Image40,
            diceImage1, diceImage2;
    public Label Label1, Label2, Label3, Label4, Label5, Label6, Label7, Label8, Label9, Label10,
            Label11, Label12, Label13, Label14, Label15, Label16, Label17, Label18, Label19, Label20,
            Label21, Label22, Label23, Label24, Label25, Label26, Label27, Label28, Label29, Label30,
            Label31, Label32, Label33, Label34, Label35, Label36, Label37, Label38, Label39, Label40;
    public Button rollDice;
    public int numOfPlayers;
    public int currentPlayer;
    public Dice dice;
    public ArrayList<Player> allPlayers;
    public HashMap<Integer, ImageView> squareCoordinates;

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        dice = new Dice();

        currentPlayer = 0;
        numOfPlayers = 1; // SHOULD BE CUSTOMIZABLE IN THE FUTURE
        allPlayers = new Player(1).createPlayers(numOfPlayers);

        //Instantiate Background Images ---- TO GO INTO EXCEL CONVERTER-----
        BackgroundImage greenBackground = new BackgroundImage(new Image("SoftwareEngineering/images/Green.png", 82, 60, true, true),
                BackgroundRepeat.NO_REPEAT, BackgroundRepeat.NO_REPEAT, BackgroundPosition.CENTER,
                BackgroundSize.DEFAULT);
        BackgroundImage deepblueBackground = new BackgroundImage(new Image("SoftwareEngineering/images/Deepblue.png", 82, 60, true, true),
                BackgroundRepeat.NO_REPEAT, BackgroundRepeat.NO_REPEAT, BackgroundPosition.CENTER,
                BackgroundSize.DEFAULT);
        BackgroundImage orangeBackground = new BackgroundImage(new Image("SoftwareEngineering/images/Orange.png", 82, 60, true, true),
                BackgroundRepeat.NO_REPEAT, BackgroundRepeat.NO_REPEAT, BackgroundPosition.CENTER,
                BackgroundSize.DEFAULT);
        BackgroundImage redBackground = new BackgroundImage(new Image("SoftwareEngineering/images/Red.png", 82, 60, true, true),
                BackgroundRepeat.NO_REPEAT, BackgroundRepeat.NO_REPEAT, BackgroundPosition.CENTER,
                BackgroundSize.DEFAULT);
        BackgroundImage lightblueBackground = new BackgroundImage(new Image("SoftwareEngineering/images/lightblue.png", 82, 60, true, true),
                BackgroundRepeat.NO_REPEAT, BackgroundRepeat.NO_REPEAT, BackgroundPosition.CENTER,
                BackgroundSize.DEFAULT);
        BackgroundImage purpleBackground = new BackgroundImage(new Image("SoftwareEngineering/images/Purple.png", 82, 60, true, true),
                BackgroundRepeat.NO_REPEAT, BackgroundRepeat.NO_REPEAT, BackgroundPosition.CENTER,
                BackgroundSize.DEFAULT);
        BackgroundImage brownBackground = new BackgroundImage(new Image("SoftwareEngineering/images/Brown.png", 82, 60, true, true),
                BackgroundRepeat.NO_REPEAT, BackgroundRepeat.NO_REPEAT, BackgroundPosition.CENTER,
                BackgroundSize.DEFAULT);
        BackgroundImage yellowBackground = new BackgroundImage(new Image("SoftwareEngineering/images/Yellow.png", 82, 60, true, true),
                BackgroundRepeat.NO_REPEAT, BackgroundRepeat.NO_REPEAT, BackgroundPosition.CENTER,
                BackgroundSize.DEFAULT);

        // A player has a position value that corresponds to the square they are in. Here we use a
        // HashMap to connect a Player's position value to the square they are associated with.
        squareCoordinates = new HashMap<Integer, ImageView>();
        squareCoordinates.put(1, Image1);
        squareCoordinates.put(2, Image2);
        squareCoordinates.put(3, Image3);
        squareCoordinates.put(4, Image4);
        squareCoordinates.put(5, Image5);
        squareCoordinates.put(6, Image6);
        squareCoordinates.put(7, Image7);
        squareCoordinates.put(8, Image8);
        squareCoordinates.put(9, Image9);
        squareCoordinates.put(10, Image10);
        squareCoordinates.put(11, Image11);
        squareCoordinates.put(12, Image12);
        squareCoordinates.put(13, Image13);
        squareCoordinates.put(14, Image14);
        squareCoordinates.put(15, Image15);
        squareCoordinates.put(16, Image16);
        squareCoordinates.put(17, Image17);
        squareCoordinates.put(18, Image18);
        squareCoordinates.put(19, Image19);
        squareCoordinates.put(20, Image20);
        squareCoordinates.put(21, Image21);
        squareCoordinates.put(22, Image22);
        squareCoordinates.put(23, Image23);
        squareCoordinates.put(24, Image24);
        squareCoordinates.put(25, Image25);
        squareCoordinates.put(26, Image26);
        squareCoordinates.put(27, Image27);
        squareCoordinates.put(28, Image28);
        squareCoordinates.put(29, Image29);
        squareCoordinates.put(30, Image30);
        squareCoordinates.put(31, Image31);
        squareCoordinates.put(32, Image32);
        squareCoordinates.put(33, Image33);
        squareCoordinates.put(34, Image34);
        squareCoordinates.put(35, Image35);
        squareCoordinates.put(36, Image36);
        squareCoordinates.put(37, Image37);
        squareCoordinates.put(38, Image38);
        squareCoordinates.put(39, Image39);
        squareCoordinates.put(40, Image40);

        StackPane2.setBackground(new Background(brownBackground));
        StackPane4.setBackground(new Background(brownBackground));
        StackPane7.setBackground(new Background(lightblueBackground));
        StackPane9.setBackground(new Background(lightblueBackground));
        StackPane10.setBackground(new Background(lightblueBackground));
        StackPane12.setBackground(new Background(purpleBackground));
        StackPane14.setBackground(new Background(purpleBackground));
        StackPane15.setBackground(new Background(purpleBackground));
        StackPane17.setBackground(new Background(orangeBackground));
        StackPane19.setBackground(new Background(orangeBackground));
        StackPane20.setBackground(new Background(orangeBackground));
        StackPane22.setBackground(new Background(redBackground));
        StackPane24.setBackground(new Background(redBackground));
        StackPane25.setBackground(new Background(redBackground));
        StackPane27.setBackground(new Background(yellowBackground));
        StackPane28.setBackground(new Background(yellowBackground));
        StackPane30.setBackground(new Background(yellowBackground));
        StackPane32.setBackground(new Background(greenBackground));
        StackPane33.setBackground(new Background(greenBackground));
        StackPane35.setBackground(new Background(greenBackground));
        StackPane38.setBackground(new Background(deepblueBackground));
        StackPane40.setBackground(new Background(deepblueBackground));

        Image1.setImage(new Image("SoftwareEngineering/images/cat.png"));
    }

    public void rolledTheDice() {
        int total = dice.roll();
        int face = dice.getFirstRoll();
        ImageView currentDice = diceImage1;
        for (int i = 0; i < 2; i++) {
            if (i == 1) {
                face = dice.getSecondRoll();
                currentDice = diceImage2;
            }
            switch (face) {
                case 1:
                    currentDice.setImage(new Image("SoftwareEngineering/images/dice-1.png"));
                    break;
                case 2:
                    currentDice.setImage(new Image("SoftwareEngineering/images/dice-2.png"));
                    break;
                case 3:
                    currentDice.setImage(new Image("SoftwareEngineering/images/dice-3.png"));
                    break;
                case 4:
                    currentDice.setImage(new Image("SoftwareEngineering/images/dice-4.png"));
                    break;
                case 5:
                    currentDice.setImage(new Image("SoftwareEngineering/images/dice-5.png"));
                    break;
                case 6:
                    currentDice.setImage(new Image("SoftwareEngineering/images/dice-6.png"));
                    break;
            }
        }
        //System.out.println("Total:" + total);
        squareCoordinates.get(allPlayers.get(currentPlayer).getPosition()).setImage(null);
        allPlayers.get(currentPlayer).newPosition(total);
        squareCoordinates.get(allPlayers.get(currentPlayer).getPosition()).setImage((new Image("SoftwareEngineering/images/cat.png")));
    }
}
