package SoftwareEngineering;

import javafx.scene.image.Image;

public class Square {
    public Image squareImage;
}

