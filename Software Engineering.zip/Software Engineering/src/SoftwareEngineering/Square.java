package SoftwareEngineering;

import javafx.scene.image.Image;
import javafx.scene.layout.BackgroundImage;

import java.util.ArrayList;

public class Square {
    public int position;
    public String name;
    public String group;
    public String action;
    public boolean canBeBought;
    public int cost;
    public Property property;

    public Square(int position, String name, String group, boolean canBeBought, int cost, Property property) {
        this.position = position;
        this.name = name;
        this.group = group;
        this.canBeBought = canBeBought;
        this.cost = cost;
        this.property = property;
    }

    public Square(int position, String name, String action, boolean canBeBought) {
        this.position = position;
        this.name = name;
        this.action = action;
        this.canBeBought = canBeBought;
    }

    public int getPosition() {
        return this.position;
    }

    public String getName() {
        return this.name;
    }

    public String getGroup(){
        return this.group;
    }

    public String getAction() {
        return this.action;
    }

    public boolean getCanBeBought() {
        return this.canBeBought;
    }

    public int getCost(){
        return this.cost;
    }

    public Property getProperty(){
        return this.property;
    }
}

