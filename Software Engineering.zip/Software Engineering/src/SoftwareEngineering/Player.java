package SoftwareEngineering;

import javafx.scene.image.Image;

import java.util.ArrayList;

public class Player {
    public int position;
    public int id;
    public Image character;

    public Player(int id) {
        position = 1;
        this.id = id;
    }

    public void newPosition(int rolledNumber) {
        position = position + rolledNumber;
        if (position > 40) {
            position -= 40;
        }
    }

    public int getPosition() {
        return this.position;
    }
    public void setPosition(int newPosition){
        this.position = newPosition;
    }

    public int getId() {
        return this.id;
    }

    public ArrayList<Player> createPlayers(int numOfPlayers) {
        ArrayList<Player> allPlayers = new ArrayList<Player>();
        for (int id = 1; id <= numOfPlayers; id++) {
            allPlayers.add(new Player(id));
        }
        return allPlayers;
    }
}

