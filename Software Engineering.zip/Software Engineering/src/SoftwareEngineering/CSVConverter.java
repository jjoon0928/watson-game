package SoftwareEngineering;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Scanner;

public class CSVConverter {
    public static ArrayList<String> cardData;
    public File file;
    public Scanner inputStream;

    // work in progress
    public CSVConverter(String filePath) throws FileNotFoundException {
        this.file = new File(filePath);
        this.inputStream = new Scanner(new BufferedReader(new FileReader(file)));
        cardData = new ArrayList<String>();
    }

    public void getCardData() {
        while (inputStream.hasNext()) {
            String data = inputStream.nextLine();
            cardData.add(data);
            //System.out.println(data);
        }
        System.out.println(cardData.toString());
        for(String element:cardData){
            System.out.println(element);
        }
        inputStream.close();
    }

    public static void main(String[] args) throws FileNotFoundException {
        CSVConverter convert = new CSVConverter("src/SoftwareEngineering/CSVData/PropertyTycoonCardData.csv");
        convert.getCardData();
    }
}
