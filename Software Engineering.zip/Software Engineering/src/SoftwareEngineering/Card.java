package SoftwareEngineering;

import java.util.ArrayList;

public class Card {
    private String description;
    private String action;

    public Card(String description, String action) {
        this.description = description;
        this.action = action;
    }

    public String getDescription() {
        return this.description;
    }

    public String getAction() {
        return this.action;
    }
}

