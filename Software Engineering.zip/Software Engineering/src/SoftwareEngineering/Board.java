package SoftwareEngineering;

public class Board {
}
