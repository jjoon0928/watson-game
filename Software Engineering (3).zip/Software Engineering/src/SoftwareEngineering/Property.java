package SoftwareEngineering;

import java.util.ArrayList;

public class Property {
    public int[] rent;
    public int currentRent;
    public String type;

    public Property(int unimproved, int house1, int house2, int house3, int house4, int hotel) {
        this.rent = new int[]{unimproved, house1, house2, house3, house4, hotel};
        this.type = "property";
        this.currentRent = 0;
    }

    public Property(String stationOrUtility) {
        if (stationOrUtility.toLowerCase().equals("station")) {
            this.rent = new int[]{25, 50, 100, 200};
            this.type = "station";
        } else if (stationOrUtility.toLowerCase().equals("utilities")) {
            this.rent = new int[]{4, 10};
            this.type = "utilities";
        }
        this.currentRent = 0;
    }

    public int[] getRent() {
        return this.rent;
    }

    public String getType() {
        return this.type;
    }

}

