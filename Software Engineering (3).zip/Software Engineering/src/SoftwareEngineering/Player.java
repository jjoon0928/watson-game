package SoftwareEngineering;

import javafx.scene.image.Image;
import javafx.scene.image.ImageView;

import java.util.ArrayList;
import java.util.jar.JarEntry;

public class Player {
    public int position;
    public int id;
    public int balance;
    public ImageView character;

    public Player(int id) {
        position = 1;
        this.id = id;
        this.balance = 1500;

        switch (id) {
            case 1:
                this.character = new ImageView(new Image("SoftwareEngineering/images/cat.png"));
                break;
            case 2:
                this.character = new ImageView(new Image("SoftwareEngineering/images/boot.png"));
                break;
            case 3:
                this.character = new ImageView(new Image("SoftwareEngineering/images/goblet.png"));
                break;
            case 4:
                this.character = new ImageView(new Image("SoftwareEngineering/images/hatstand.png"));
                break;
            case 5:
                this.character = new ImageView(new Image("SoftwareEngineering/images/smartphone.png"));
                break;
            case 6:
                this.character = new ImageView(new Image("SoftwareEngineering/images/spoon.png"));
        }
    }

    public void newPosition(int rolledNumber) {
        position = position + rolledNumber;
        if (position > 40) {
            position -= 40;
        }
    }

    public int getPosition() {
        return this.position;
    }

    public void setPosition(int newPosition) {
        this.position = newPosition;
    }

    public void setBalance(int newBalance) {
        this.balance = newBalance;
    }

    public int getBalance() {
        return this.balance;
    }

    public int getId() {
        return this.id;
    }

    public ImageView getCharacter() {
        return this.character;
    }

    public ArrayList<Player> createPlayers(int numOfPlayers) {
        ArrayList<Player> allPlayers = new ArrayList<Player>();
        for (int id = 1; id <= numOfPlayers; id++) {
            allPlayers.add(new Player(id));
        }
        return allPlayers;
    }
}

